/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.models;

import java.util.Objects;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author geobude
 */
public class Product {

   
  private SimpleLongProperty uniqueId;
  private SimpleStringProperty productCode;  
  private SimpleStringProperty productName;
  private SimpleStringProperty productCategory;
  private  SimpleBooleanProperty available;
  private SimpleDoubleProperty productPrice;
  private  SimpleIntegerProperty quantityOnHand;

    public Product(Long uniqueId, String productCode, String productName, String productCategory, Boolean available, Double productPrice, Integer quantityOnHand) {
        this.uniqueId=new SimpleLongProperty(uniqueId);
        this.productCode=new SimpleStringProperty(productCode);
        this.productName=new SimpleStringProperty(productName);
        this.productCategory=new SimpleStringProperty(productCategory);
        this.available=new SimpleBooleanProperty(available);
        this.productPrice=new SimpleDoubleProperty(productPrice);
        this.quantityOnHand=new SimpleIntegerProperty(quantityOnHand);
    }

    @Override
    public String toString() {
        return "Product{" + "uniqueId=" + uniqueId + ", productCode=" + productCode + ", productName=" + productName + ", productCategory=" + productCategory + ", available=" + available + ", productPrice=" + productPrice + ", quantityOnHand=" + quantityOnHand + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + Objects.hashCode(this.uniqueId);
        hash = 67 * hash + Objects.hashCode(this.productCode);
        hash = 67 * hash + Objects.hashCode(this.productName);
        hash = 67 * hash + Objects.hashCode(this.productCategory);
        hash = 67 * hash + Objects.hashCode(this.available);
        hash = 67 * hash + Objects.hashCode(this.productPrice);
        hash = 67 * hash + Objects.hashCode(this.quantityOnHand);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Product other = (Product) obj;
        if (!Objects.equals(this.productCode, other.productCode)) {
            return false;
        }
        if (!Objects.equals(this.productName, other.productName)) {
            return false;
        }
        if (!Objects.equals(this.productCategory, other.productCategory)) {
            return false;
        }
        return true;
    }
    
    // these getters retun the object properties
     

    public SimpleLongProperty uniqueIdProperty() {
        return uniqueId;
    }

    public SimpleStringProperty productCodeProperty() {
        return productCode;
    }

    public SimpleStringProperty productNameProperty() {
        return productName;
    }

    public SimpleStringProperty productCategoryProperty() {
        return productCategory;
    }

    public SimpleBooleanProperty availableProperty() {
        return available;
    }

    public SimpleDoubleProperty productPriceProperty() {
        return productPrice;
    }

    public SimpleIntegerProperty quantityOnHandProperty() {
        return quantityOnHand;
    }    
    
    
    
   //The getters below return the actual data from properties
    public Long getUniqueId() {
        return uniqueId.get();
    }

    public String getProductCode() {
        return productCode.get();
    }

    public String getProductName() {
        return productName.get();
    }

    public String getProductCategory() {
        return productCategory.get();
    }

    public Boolean isAvailable() {
        return available.get();
    }

    public Double getProductPrice() {
        return productPrice.get();
    }

    public Integer getQuantityOnHand() {
        return quantityOnHand.get();
    }

    
    //Setters
    public void setUniqueId(Long uniqueId) {
        this.uniqueId.set(uniqueId);
    }

    public void setProductCode(String productCode) {
        this.productCode.set(productCode);
    }

    public void setProductName(String productName) {
        this.productName.set(productName);
    }

    public void setProductCategory(String productCategory) {
        this.productCategory.set(productCategory);
    }

    public void setAvailable(Boolean available) {
        this.available.set(available);
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice.set(productPrice);
    }

    public void setQuantityOnHand(Integer quantityOnHand) {
        this.quantityOnHand.set(quantityOnHand);
    }

    
   
   

}