/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.database;

//import java.math.BigDecimal;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.java.models.Product;
import main.java.models.ProductProperty;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.apache.derby.drda.NetworkServerControl;

/**
 *
 * @author geobude
 */
public class ProductDatabaseHandler implements ProductDatabaseAccess {
   private static Connection connection=null;
   /* private static final String DB_URL_CONNECT="jdbc:derby:IMdatabase";
   private static final String DB_URL_OPEN="jdbc:derby:IMdatabase;create=true";
   private static final String DB_URL="jdbc:derby://localhost:1555/INVENTORY_MASTER;create=true";
   private static final String DB_URL_CLOSE="jdbc:derby:IMdatabase;shutdown=true";*/
   
   private static final String DB_URL_CONNECT="jdbc:derby://localhost:1555/INVENTORY_MASTER";
   private static final String DB_URL_OPEN="jdbc:derby:IMdatabase;create=true";
   private static final String DB_URL="jdbc:derby://localhost:1555/INVENTORY_MASTER;create=true";
   private static final String DB_URL_CLOSE="jdbc:derby://localhost:1555/INVENTORY_MASTER;shutdown=true";
   
   private QueryRunner queryRunner;
   private Statement statement=null;
   //private final String DB_DRIVER="org.apache.derby.jdbc.EmbeddedDriver";
   private final String DB_DRIVER="org.apache.derby.jdbc.ClientDriver";
   private static final List<Product> EMPTY_PRODUCT_LIST=new ArrayList<>();
   private static final List<Product> EMPTY_PRODUCT_LIST_ARRAY=new ArrayList<>();
   private static final List EMPTY_LIST=new ArrayList<>();
   private   ObservableList<Product> products ;
    
    public ProductDatabaseHandler()
    {
        queryRunner=new QueryRunner();
    }
    @Override
    public void setup() throws Exception {
    //derby.drda.startNetworkServer=true;
  NetworkServerControl server = new NetworkServerControl(InetAddress.getByName("localhost"),1555);

java.io.PrintWriter consoleWriter = new java.io.PrintWriter(System.out, true);
server.start(consoleWriter);
        connection=DriverManager.getConnection(DB_URL);
        statement=connection.createStatement();
        DatabaseMetaData dbMetaData=connection.getMetaData();
        ResultSet tables= dbMetaData.getTables(null,null,"PRODUCT",null);
        if(!tables.next()){         
        try{
     
        Class.forName(DB_DRIVER).newInstance();
        
        queryRunner.update(connection, "CREATE TABLE Product("
                + "uniqueId BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"
                + "productCode VARCHAR(30), productName VARCHAR(50), productCategory VARCHAR(50), productPrice DOUBLE, "
                + " available BOOLEAN, quantityOnHand INTEGER )");
            }catch(SQLException e){
                  System.out.println("\t----------setup-----------\n" + e.getMessage() + "\n\t---------------------\n");
              //  System.err.println(e.getMessage());
         }
       }
  }
       
      

    @Override
    public void connect() throws Exception {
        try{
        connection=DriverManager.getConnection(DB_URL_CONNECT);
        }catch(Exception e){
            e.printStackTrace();
        }
         }

    @Override
    public void close() throws Exception {
     try{
        //connection.close();
        DbUtils.close(connection);
        DriverManager.getConnection(DB_URL_CLOSE);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public String addProduct(Product product) {
       
        try{
        queryRunner.insert(connection,"INSERT INTO Product(productCode, productName, productCategory, productPrice, available, quantityOnHand)"
                  +"VALUES(?,?,?,?,?,?)",new ScalarHandler<BigDecimal>(),product.getProductCode(),
                  product.getProductName(),product.getProductCategory(),product.getProductPrice(),
                  product.isAvailable(), product.getQuantityOnHand()).longValue();

                    return product.getProductName();
 
                    }
                    catch(SQLException e){
                         System.out.println("\t----------add-----------\n" + e.getMessage() + "\n\t---------------------\n");
                               e.printStackTrace();
                    }
              return null;
       }

    @Override
    public boolean updateProduct(Product product) {
       try{
        queryRunner.update(connection,"UPDATE Product SET productCode=?, productName=?, productCategory=?, productPrice=?,"
                  +"available=?, product=? WHERE uniqueId=?",product.getProductCode(),
                  product.getProductName(),product.getProductCategory(),product.getProductPrice(),
                  product.isAvailable(), product.getQuantityOnHand(), product.getUniqueId());

                    return true;
 
                    }
                    catch(SQLException e){
                              e.printStackTrace();
                    }
           finally{
           try {
               DbUtils.close(connection);
           } catch (SQLException ex) {
               Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
           }
       
            }
              return false;
    }

    @Override
    public boolean removeProduct(Product product) {
        try{
        queryRunner.update("DELETE FROM Product  WHERE uniqueId=?", product.getUniqueId());

                    return true;
 
                    }
                    catch(SQLException e){
                              e.printStackTrace();
                    }
         finally{
            try {
                DbUtils.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
       
            }
              return false;  }

    @Override
    public List<Product> searchProduct(ProductProperty productProperty, Object value) {
       String whereClause="";
       String valueClause="";
        //String valueClause=value.toString();
            switch(productProperty)
            {
           case ID:
               whereClause="productCode=?";
               valueClause=value.toString();
               break;
           case NAME:
               whereClause="productName LIKE ?";
               valueClause= "%"+ value.toString()+"%";
               break;
           case CATEGORY:
               whereClause="productCategory LIKE ?";
               valueClause= "%"+ value.toString()+"%";
               break;
           case AVALABILITY:
               whereClause="availability=?";
                //valueClause=value.toString();
               break;
           default:
               throw new AssertionError(productProperty.name());
            }
        try{
       return  queryRunner.query(connection, "SELECT * FROM Product  WHERE "+whereClause, new BeanListHandler <Product>(Product.class), valueClause);
            }
        catch(SQLException e){
             System.out.println("\t----------seaarch by propertie-----------\n" + e.getMessage() + "\n\t---------------------\n");
                        
                  e.printStackTrace();
              }
         finally{
           try {
               DbUtils.close(connection);
           } catch (SQLException ex) {
               Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
           }
       
            }
          return EMPTY_PRODUCT_LIST; 
    

    }

   
    @Override
    public List<Product> searchAllProducts() {
        ResultSetHandler<List<Product>> p = new BeanListHandler<>(Product.class);
       
        try{
       return   (List<Product>) queryRunner.query(connection, "SELECT * FROM PRODUCT", p);
            }
        catch(SQLException e){
                                    
                  e.printStackTrace();
              }
         finally{
            try {
                DbUtils.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
       
            }
          return EMPTY_PRODUCT_LIST; }
    
    /* public List searchAllProduct() {
    // ResultSetHandler<List<Product>> p = new BeanListHandler<>(Product.class);
    // ResultSetHandler<List<Student>> resultSetHandler = new BeanListHandler<Student>(Student.class);
    ResultSetHandler h = new ArrayListHandler();
    try{
    return   (List) queryRunner.query(connection, "SELECT * FROM PRODUCT", h);
    }
    catch(SQLException e){
    System.out.println("\t----------show all-----------\n" + e.getMessage() + "\n\t---------------------\n");
    
    e.printStackTrace();
    }
    finally{
    try {
    DbUtils.close(connection);
    } catch (SQLException ex) {
    Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    }
    return EMPTY_LIST; }
    */
    
   @Override
     public ObservableList<Product> searchAllProduct() {
      //List<Product>  products=new ArrayList<>();
      products = FXCollections.observableArrayList();
      
        try{
         statement = connection.createStatement();
        ResultSet rs = statement.executeQuery("SELECT * FROM PRODUCT");  
        while(rs.next()) {
          Product product = new Product(rs.getLong("uniqueId"),rs.getString("productCode"),rs.getString("productName"),rs.getString("productCategory"),rs.getBoolean("available"),rs.getDouble("productPrice"), rs.getInt("quantityOnHand"));      
          products.add(product);
         
            }
        return products;
        }
        catch(SQLException e){
             System.out.println("\t----------show all-----------\n" + e.getMessage() + "\n\t---------------------\n");
                        
                  e.printStackTrace();
              }
         finally{
            try {
                DbUtils.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
       
            }
          return null; }
    
    
   @Override
    public void selectAll()
    {
    
       try {
           String sql = "select * from Product";  // use actual productName of the table
           PreparedStatement neno = connection.prepareStatement(sql);
              ResultSet rs = neno.executeQuery();
              System.out.println("------------select all---------\n Executed well \n\t-----------------");
              while(rs.next()){
                  System.out.println(rs.getString(2));
              
              }
              System.out.println(rs.toString());
       } catch (SQLException ex) {
           System.out.println("------------select all---------\n"+ex.getMessage()+"\n\t-----------------");
           Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
       }
       finally{
       try {
                DbUtils.close(connection);
            } catch (SQLException ex) {
                Logger.getLogger(ProductDatabaseHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
       }
    
    }
 
    
}
