/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.database;
import java.util.List;
import main.java.models.Product;
import main.java.models.ProductProperty;

/**
 *
 * @author geobude
 */
public interface ProductDatabaseAccess extends DatabaseAccess{
    /* public String addProduct(Product product) throws Exception;
    public boolean updateProduct(Product product) throws Exception;
    public boolean removeProduct(Product product) throws Exception;
    public List<Product> searchProduct(ProductProperty productProperty, Object value) throws Exception;
    public List<Product> searchAllProducts() throws Exception;*/
     public String addProduct(Product product) ; 
   public boolean updateProduct(Product product);
   public boolean removeProduct(Product product);
   public List<Product> searchProduct(ProductProperty productProperty, Object value);
   public List<Product> searchAllProducts();

    public void selectAll();

    public List searchAllProduct();

}
