/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.controllers;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuBar;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import main.java.database.ProductDatabaseAccess;
import main.java.database.ProductDatabaseHandler;
import main.java.models.Product;
import main.java.models.ProductProperty;

/**
 * FXML Controller class
 *
 * @author geobude
 */
public class InventoryMasterMainViewController implements Initializable {

    @FXML
    private ChoiceBox<ProductProperty> choiceBoxSearchProduct;
    @FXML
    private AnchorPane mainAnchorPane;
    @FXML
    private StackPane mainStackPane;
    @FXML
    private BorderPane mainBorderPane;
    @FXML
    private MenuBar mainMenuBar;
    @FXML
    private TabPane mainTabPane;
    @FXML
    private Tab homeTab;
    @FXML
    private AnchorPane homeTabAchorPane;
    @FXML
    private SplitPane homeSplitPane;
    @FXML
    private AnchorPane homeSplitPaneLeftAnchorPane;
    @FXML
    private VBox homeLeftAnchorPaneVbox;
    @FXML
    private HBox searchProductHbox;
    @FXML
    private Label labelSearchProduct;
    @FXML
    private TextField textFieldSearch;
    @FXML
    private TableView<Product> productTableView;
    @FXML
    private AnchorPane homeSplitPaneRightAnchorPane;
    @FXML
    private Tab salesTab;
    @FXML
    private JFXButton buttonAddNewProduct;
    @FXML
    private ListView<Product> listViewProductDetails;
    @FXML
    private TableColumn<Product, String> productIdColumn;
    @FXML
    private TableColumn<Product, String> productNameColumn;
    @FXML
    private TableColumn<Product, String> productCategoryColumn;
    @FXML
    private TableColumn<Product, Number> productQuantityColumn;
    @FXML
    private TableColumn<Product, Number> productPriceColumn;
    private ObservableList<Product> productObjectDataRows ;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        choiceBoxSearchProduct.getItems().setAll(ProductProperty.values());
        choiceBoxSearchProduct.getSelectionModel().selectFirst();
      
       // listViewProductDetails.getItems().setAll(productDatabaseHandler().searchAllProducts());
          this.setProductDetailsListView();
          this.setproductTableView();
        // TODO
    }    
     private ProductDatabaseAccess productDatabaseHandler() {
    
         return new ProductDatabaseHandler();
    }
    public void switchStage(String fxml, String stageTitle, boolean resizable)
{
    
    FXMLLoader loader=new FXMLLoader((getClass().getResource(fxml)));
            Parent root;
            
            
      try {
          root = loader.load();
          Stage stage=new Stage(StageStyle.DECORATED);
          stage.setTitle(stageTitle);
          stage.setScene(new Scene(root));
          stage.setResizable(resizable);
          stage.show();
        } catch (IOException ex) {
            Logger.getLogger(InventoryMasterMainViewController.class.getName()).log(Level.SEVERE, null, ex);
        } 
    
}

    @FXML
    private void callAddNewProductAction(ActionEvent event) {
        switchStage("/main/resource/views/AddNewProduct.fxml", "CREATE NEW PRODUCT",false);
    }
  
    public ObservableList<Product> getProductObjectDataRows() {
        try {
            productDatabaseHandler().setup();
            productObjectDataRows = FXCollections.observableArrayList((ObservableList<Product>)(productDatabaseHandler().searchAllProduct()));
            return productObjectDataRows;
        } catch (Exception ex) {
            Logger.getLogger(InventoryMasterMainViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
      
    public void setproductTableView(){
    
    productIdColumn.setCellValueFactory(cellData -> cellData.getValue().productCodeProperty());
    productNameColumn.setCellValueFactory(cellData -> cellData.getValue().productNameProperty());
    productCategoryColumn.setCellValueFactory(cellData -> cellData.getValue().productCategoryProperty());
    productQuantityColumn.setCellValueFactory(cellData -> cellData.getValue().quantityOnHandProperty());
    productPriceColumn.setCellValueFactory(cellData -> cellData.getValue().productPriceProperty());
    productTableView.setItems(getProductObjectDataRows());
   
    }
    
    public void setProductDetailsListView()
    {
        try {
           
         productDatabaseHandler().setup();
        List<Product> products =productDatabaseHandler().searchAllProduct();
        
        for(int i = 0; i <products.size (); i++) 
        { 
        Product product = (Product) products.get (i); 
        listViewProductDetails.getItems().addAll(product);
         System.out.println ("id:" + product.getProductCode() + "; name:" + product.getProductName()); 
         } 
         //for (List product : products) {
              //System.out.println(Arrays.toString(product));
         //listViewProductDetails.getItems().add(Arrays.toString(product));
         //}
            
          // listViewProductDetails.getItems().setAll(productDatabaseHandler().searchAllProducts());
           //List<Product> list=productDatabaseHandler().searchAllProducts();
            //String products = Arrays.toString(list.toArray());
            //System.out.println(products);
        
        } catch (Exception ex) {
            Logger.getLogger(InventoryMasterMainViewController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
//listViewProductDetails