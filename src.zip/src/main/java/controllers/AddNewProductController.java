/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.controllers;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import static java.lang.Double.parseDouble;
//import static java.lang.double.parsedouble;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import main.java.database.ProductDatabaseAccess;
import main.java.database.ProductDatabaseHandler;
import main.java.models.Product;

/**
 * FXML Controller class
 *
 * @author geobude
 */
public class AddNewProductController implements Initializable {

   private Product product;
    @FXML
    private AnchorPane anchorPaneAddProduct;
    @FXML
    private VBox VBoxAddProduct;
    @FXML
    private JFXTextField textBoxAddProductID;
    @FXML
    private JFXTextField textBoxAddProductName;
    @FXML
    private JFXTextField textBoxAddProductCategory;
    @FXML
    private JFXTextField textBoxAddProductPrice;
    @FXML
    private JFXTextField textBoxAddProductNumber;
    @FXML
    private JFXButton buttonAddProductAdd;
    @FXML
    private JFXButton buttonAddProductReset;
    @FXML
    private JFXButton buttonAddProductCancel;

    private InventoryMasterMainViewController mainController;
    private ProductDatabaseAccess productDatabaseHandler() {
    
         return new ProductDatabaseHandler();
    }
    /**
     * Initializes the controller class.
     */
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         //anchorPaneAddProduct.isResizable(false);
    }    

    @FXML
    private void addNewProductAction(ActionEvent event) {
              
         String id= textBoxAddProductID.getText();
        String productName= textBoxAddProductName.getText();
        String productCategory= textBoxAddProductCategory.getText();
        if(id.isEmpty() || productName.isEmpty()|| productCategory.isEmpty()|| textBoxAddProductPrice.getText().isEmpty()||textBoxAddProductNumber.getText().isEmpty())
       {
       System.out.println("empty field");
       return;
       }
        double productPrice=parseDouble(textBoxAddProductPrice.getText());
       int quantityOnHand=parseInt(textBoxAddProductNumber.getText());
       
    product=new Product(0L,id,productName, productCategory, true,productPrice, quantityOnHand);
       try {
            productDatabaseHandler().setup();
           productDatabaseHandler().addProduct(product);  
           mainController=new InventoryMasterMainViewController();
           mainController.setproductTableView();
           
           
       } catch (Exception ex) {
           System.out.println("\t--------controller-------------\n" + ex.getMessage() + "\n\t---------------------\n");
                      Logger.getLogger(AddNewProductController.class.getName()).log(Level.SEVERE, null, ex);
                      
       }
    }
}
