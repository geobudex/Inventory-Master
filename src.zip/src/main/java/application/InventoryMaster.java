/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.application ;
//package main.resource.views;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import main.java.controllers.InventoryMasterMainViewController;

import main.java.database.ProductDatabaseAccess;
import main.java.database.ProductDatabaseHandler;

/**
 *
 * @author geobude
 */
public class InventoryMaster extends Application{

    //FXMLLoader loader;
    //InventoryMasterMainViewController inventoryMasterMainViewController;
    /*private  ProductDatabaseAccess productDatabaseHandler()
    {
    return new ProductDatabaseHandler();
    }
    InventoryMaster()
    {
    
    }*/
    @Override
    public void start(Stage primaryStage) throws Exception {
    //inventoryMasterMainViewController  =  loader.getController();
     

            FXMLLoader loader=new FXMLLoader((getClass().getResource("/main/resource/views/InventoryMasterMainView.fxml")));
            Parent root=loader.load();
            Scene scene=new Scene(root);
           // scene.getStylesheets().add(""); 
              primaryStage.setScene(scene);
               primaryStage.setTitle("INVENTORY MASTER APPLICATION");
                primaryStage.show();
        
          
    }
     public static void main(String[] args) {
        launch(args);
    }
    
}


